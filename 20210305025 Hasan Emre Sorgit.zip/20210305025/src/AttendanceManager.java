interface AttendanceManager {
    void markAttendance(String identifier);
    void displayAttendance();
    void incrementAbsences(String identifier);
}