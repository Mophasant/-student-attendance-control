import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

class AttendanceTracker implements AttendanceManager {
    private Map<String, Integer> absences = new HashMap<>();
    private Map<String, Boolean> attendance = new HashMap<>();
    private List<Student> students;
    private int totalClasses = 11;
    private int currentClass = 8;

    public AttendanceTracker(List<Student> students) {
        this.students = students;
        students.forEach(s -> {
            absences.put(s.getId(), new Random().nextInt(6));
            attendance.put(s.getId(), false);
        });
    }

    @Override
    public void markAttendance(String identifier) {
        students.stream()
                .filter(s -> s.getId().equals(identifier) || s.getName().equalsIgnoreCase(identifier) || s.getNumericId().equals(identifier))
                .findFirst()
                .ifPresentOrElse(
                        s -> {
                            attendance.put(s.getId(), true);
                            System.out.println(s.getName() + " is present.");
                        },
                        () -> System.out.println("Student not found: " + identifier)
                );
    }

    @Override
    public void displayAttendance() {
        System.out.println("\nAttendance Report:");
        students.forEach(s -> {
            int abs = absences.get(s.getId());
            String status = abs >= 5 ? "Failed the grade" : "Absent: " + abs;
            System.out.println(s.getName() + " (ID: " + s.getNumericId() + ") - " + status);
        });
    }

    @Override
    public void incrementAbsences(String identifier) {
        students.stream()
                .filter(s -> s.getId().equals(identifier) || s.getName().equalsIgnoreCase(identifier) || s.getNumericId().equals(identifier))
                .findFirst()
                .ifPresentOrElse(
                        s -> {
                            absences.put(s.getId(), absences.get(s.getId()) + 1);
                            System.out.println(s.getName() + "'s absences increased.");
                        },
                        () -> System.out.println("Student not found: " + identifier)
                );
    }

    public void updateAbsencesForUnmarked() {
        students.stream()
                .filter(s -> !attendance.get(s.getId()))
                .forEach(s -> absences.put(s.getId(), absences.get(s.getId()) + 1));
    }

    public void showClassInfo() {
        System.out.println("Class " + currentClass + " of " + totalClasses + ". Remaining: " + (totalClasses - currentClass));
    }

    public boolean nextClass() {
        if (currentClass < totalClasses) {
            currentClass++;
            return true;
        }
        return false;
    }
}