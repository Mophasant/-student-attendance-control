import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class Personal {
    public static void main(String[] args) {
        List<Student> students = new ArrayList<>();


        String[] turkishNames = {
                "Ahmet", "Mehmet", "Fatma", "Ayşe", "Ali", "Zeynep", "Hüseyin", "Elif", "Mustafa", "Emine",
                "Hasan", "Hatice", "Murat", "Sevgi", "Kemal", "Gül", "Ramazan", "Leyla", "Osman", "Perihan"
        };

        for (int i = 1; i <= 20; i++) {
            students.add(new Student("S" + i, turkishNames[i - 1], String.valueOf(i)));
        }

        AttendanceTracker tracker = new AttendanceTracker(students);
        Scanner scanner = new Scanner(System.in);

        while (true) {
            tracker.showClassInfo();

            System.out.println("Enter IDs or names to mark attendance (comma separated):");
            String input = scanner.nextLine();
            Arrays.stream(input.split(","))
                    .map(String::trim)
                    .forEach(tracker::markAttendance);

            tracker.updateAbsencesForUnmarked();
            tracker.displayAttendance();

            if (!tracker.nextClass()) {
                System.out.println("You have successfully completed the semester.");
                break;
            }

            System.out.println("Do you want to continue? (yes/no):");
            if (scanner.nextLine().equalsIgnoreCase("no")) {
                break;
            }
        }
        scanner.close();
    }
}
