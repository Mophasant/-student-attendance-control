class Student {
    private String id;
    private String name;
    private String numericId;

    public Student(String id, String name, String numericId) {
        this.id = id;
        this.name = name;
        this.numericId = numericId;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getNumericId() {
        return numericId;
    }
}